package com.example.example;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RequestsAdminActivity extends AppCompatActivity {//בקשות של מחיקת ופתיחת מקלט

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requests_admin);
    }
}
